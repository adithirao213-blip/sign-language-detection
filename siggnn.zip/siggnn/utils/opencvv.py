import cv2

cap = cv2.VideoCapture(0)  # or your video file path

cv2.namedWindow("Full Screen Video", cv2.WINDOW_NORMAL)
cv2.setWindowProperty("Full Screen Video", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    cv2.imshow("Full Screen Video", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to quit
        break

cap.release()
cv2.destroyAllWindows()
